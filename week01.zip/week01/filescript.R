# Author    : allqoow
# Contact   : allqoow@gmail.com
# Started on: 20161030(yyyymmdd)
# Project   : exerciseML(Exercise for Microeconometrics)

# 5
x = rnorm(100)
plot(x)